Anh Quang Chu 015332629 
Brian Tran 010647299
To run IsolationTest.java, run the command java -cp ".:mysql-connector-j-8.0.32.jar" IsolationTest
At the beginning of the main method there are variables mysqlConnection, mysqlUsername, and mysqlPassword that can be modified for connecting to different servers.